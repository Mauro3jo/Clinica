<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Clínica</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</head>
<body>
    <div id="app"></div>
</body>
</html>
<?php /**PATH C:\Users\mauro_j2pjkpe\OneDrive\Documentos\GitHub\Clinica\Clinica\resources\views/app.blade.php ENDPATH**/ ?>